import 'package:flutter/material.dart';
import 'package:untitled9/Question.dart';

class GoLevel extends StatefulWidget {
  const GoLevel({Key key}) : super(key: key);

  @override
  _GoLevelState createState() => _GoLevelState();
}

class _GoLevelState extends State<GoLevel> {
  Question q = Question();
  bool CorrectAnswer ;
  void Answers (bool choice){
    if (choice==CorrectAnswer){
      setState(() {
        scoreIcon.add(Icon(Icons.close,size: 30,color: Colors.green,));

      });
    }
    else
      setState(() {
        scoreIcon.add(Icon(Icons.check_box,size: 30,color: Colors.green,));
      });
      print(false);


  }
  List<Icon>scoreIcon=[];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.indigo,
          title: Text('Level 1'),
        ),
        body: Container(
          color: Colors.indigo,
          width: 800,
          height: 800,
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              Expanded(
                flex: 4,
                child: Text(
                  q.Questions[0].questionText,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Image.network(
                'https://cdn.mos.cms.futurecdn.net/YMtayWGwpiau57vwqDrDad.jpg',
                width: 350,
                height: 350,
              ),
              SizedBox(
                height: 30,
              ),
              Expanded(
                child: FlatButton(
                  minWidth: 300,
                  color: Colors.green,
                  onPressed:  (){
                    CorrectAnswer= q.Questions[0].questionAnswer ;
                    Answers(true);
                  },
                  child:
                  Text('True',style: TextStyle(fontSize: 40)),
                ),
              ),
              SizedBox(
                height: 40,
              ),

              Expanded(
                child: FlatButton(
                  minWidth: 300,
                  color: Colors.red,
                  onPressed:  (){
                    CorrectAnswer= q.Questions[0].questionAnswer ;
                    Answers(false);
                  },
                  child:
                  Text('False',style: TextStyle(fontSize: 40)),
                ),
              ),

              SizedBox(
                height: 50,
              ),
              Row(
                children:
                  scoreIcon,
              )

            ],
          ),
        ));
  }
}
