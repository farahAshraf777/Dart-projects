class QuestionsClass{
  final String questionText;
  final bool questionAnswer;
  QuestionsClass({this.questionAnswer,this.questionText});

}
class Question{
  List<QuestionsClass> Questions = [
  QuestionsClass(questionText:'Is the earth is planet?',questionAnswer: false),
  ];
}