import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled9/go_to_level.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Stack(

            alignment: Alignment.bottomLeft,
            children: [
              Image.network('https://ar.apkshki.com/storage/7146/icon_5f919507bc0f2_7146.png'),
              Text('Quizzles',
              style: TextStyle(
                fontSize: 50, color: Colors.white ,
                fontWeight: FontWeight.bold,
              ),)
            ],
          ),
            Expanded(
              flex: 4,
              child:
              Text('Lets Play !' ,
                style: TextStyle(
                    color: Colors.purple , fontSize: 35 ,
                    fontWeight: FontWeight.bold ,
                ),),
            ),
          SizedBox(height: 1),
          Expanded(
            flex: 1,
              child:
          ButtonTheme(
            minWidth: 300,
            buttonColor: Colors.deepPurpleAccent,
            child: RaisedButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>GoLevel())).then((value) => setState((){}));
              },
              child:  Text('Play Now',style: TextStyle(fontSize: 32 ,color: Colors.white ),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30)
              ),
            ),
          )),
          SizedBox(height: 20,),
          Expanded(
              flex: 1,
              child:
              ButtonTheme(
                minWidth: 300,
                buttonColor: Colors.deepPurpleAccent,
                child: RaisedButton(
                  onPressed: (){},
                  child:  Text('About',style: TextStyle(fontSize: 32 ,color: Colors.white),),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)
                  ),
                ),
              )),
          SizedBox(height: 100,),


        ],
      ),

    );
  }
}
